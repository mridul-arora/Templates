A Pen created at CodePen.io. You can find this one at https://codepen.io/the-scripter/pen/qLXOge.

 A resposive expanding column layout to present projects, articles, and more.