A Pen created at CodePen.io. You can find this one at http://codepen.io/paulhbarker/pen/apvGdv.

 Column-based flexbox timeline layout. The goal is to have clean, semantic HTML while creating a (somewhat complex) timeline-looking layout.